# Expressjs API Example

#### In `app.js`, there are all methods, routes, and middlewares explained in comments.

#### There is also another way like exporting the router and using it, but...  **WE DON'T DO THAT** (I'm lazy).

### If I missed any method or middleware, feel free to make a PR with an explanation.

### If you need more details, then head over to the Express.js [docs](https://expressjs.com).

---

###### If you have any doubts, contact me. I'll respond when I'm bored...
###### [Contact](https://github.com/IRON-M4N)
